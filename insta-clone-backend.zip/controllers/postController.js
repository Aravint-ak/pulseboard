const Post = require('../models/Post');

const createPost = async (req, res) => {
  const { caption, imageUrl } = req.body;
  if (!caption) return res.status(400).json({ message: 'Caption is required' });

  const post = await Post.create({
    user: req.user._id,
    caption,
    imageUrl,
  });

  res.status(201).json(post);
};

const getAllPosts = async (req, res) => {
  const posts = await Post.find()
    .sort({ createdAt: -1 })
    .populate('user', 'name email')
    .populate({ path: 'comments', populate: { path: 'user', select: 'name email' } });

  res.json(posts);
};

const getUserPosts = async (req, res) => {
  const posts = await Post.find({ user: req.params.userId })
    .sort({ createdAt: -1 })
    .populate('user', 'name email');

  res.json(posts);
};

const getPostById = async (req, res) => {
  const post = await Post.findById(req.params.id)
    .populate('user', 'name email')
    .populate({ path: 'comments', populate: { path: 'user', select: 'name email' } });

  if (!post) return res.status(404).json({ message: 'Post not found' });

  res.json(post);
};

module.exports = { createPost, getAllPosts, getUserPosts, getPostById };
