const Comment = require('../models/Comment');
const Post = require('../models/Post');

const addComment = async (req, res) => {
  const { text } = req.body;
  const { postId } = req.params;

  if (!text) return res.status(400).json({ message: 'Comment text required' });

  const post = await Post.findById(postId);
  if (!post) return res.status(404).json({ message: 'Post not found' });

  const comment = await Comment.create({ post: postId, user: req.user._id, text });

  post.comments.push(comment._id);
  await post.save();

  const populated = await Comment.findById(comment._id).populate('user', 'name email');

  res.status(201).json(populated);
};

const getComments = async (req, res) => {
  const comments = await Comment.find({ post: req.params.postId })
    .sort({ createdAt: -1 })
    .populate('user', 'name email');

  res.json(comments);
};

const deleteComment = async (req, res) => {
  const comment = await Comment.findById(req.params.id);
  if (!comment) return res.status(404).json({ message: 'Comment not found' });

  if (comment.user.toString() !== req.user._id.toString()) {
    return res.status(401).json({ message: 'Not authorized' });
  }

  await comment.remove();
  res.json({ message: 'Comment removed' });
};

module.exports = { addComment, getComments, deleteComment };
