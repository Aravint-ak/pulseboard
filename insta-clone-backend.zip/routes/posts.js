const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { createPost, getAllPosts, getUserPosts, getPostById } = require('../controllers/postController');

router.get('/', getAllPosts);
router.post('/', protect, createPost);
router.get('/user/:userId', getUserPosts);
router.get('/:id', getPostById);

module.exports = router;
